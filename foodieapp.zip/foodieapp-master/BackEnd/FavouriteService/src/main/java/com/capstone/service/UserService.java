package com.capstone.service;

import com.capstone.entity.User;

public interface UserService {
    public abstract User addUser(User user);
}